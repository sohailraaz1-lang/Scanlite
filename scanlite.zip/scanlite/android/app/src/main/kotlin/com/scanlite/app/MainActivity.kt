package com.scanlite.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
