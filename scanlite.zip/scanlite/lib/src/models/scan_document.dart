import 'dart:convert';

/// A single scanned page. Pages are stored as image files on disk; only the
/// relative file name and small metadata live in the index.
class ScanPage {
  ScanPage({
    required this.id,
    required this.fileName,
    this.rotationQuarterTurns = 0,
    this.ocrText,
  });

  final String id;
  final String fileName;
  int rotationQuarterTurns;
  String? ocrText;

  Map<String, dynamic> toJson() => {
        'id': id,
        'fileName': fileName,
        'rotation': rotationQuarterTurns,
        'ocrText': ocrText,
      };

  factory ScanPage.fromJson(Map<String, dynamic> json) => ScanPage(
        id: json['id'] as String,
        fileName: json['fileName'] as String,
        rotationQuarterTurns: (json['rotation'] as int?) ?? 0,
        ocrText: json['ocrText'] as String?,
      );
}

/// A document is an ordered list of pages plus a title and timestamps.
class ScanDocument {
  ScanDocument({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.pages,
  });

  final String id;
  String title;
  final DateTime createdAt;
  DateTime modifiedAt = DateTime.now();
  final List<ScanPage> pages;

  int get pageCount => pages.length;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'createdAt': createdAt.toIso8601String(),
        'modifiedAt': modifiedAt.toIso8601String(),
        'pages': pages.map((p) => p.toJson()).toList(),
      };

  factory ScanDocument.fromJson(Map<String, dynamic> json) => ScanDocument(
        id: json['id'] as String,
        title: json['title'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        pages: (json['pages'] as List<dynamic>)
            .map((e) => ScanPage.fromJson(e as Map<String, dynamic>))
            .toList(),
      )
        ..modifiedAt =
            DateTime.tryParse(json['modifiedAt'] as String? ?? '') ??
                DateTime.now();

  String encode() => jsonEncode(toJson());
}
