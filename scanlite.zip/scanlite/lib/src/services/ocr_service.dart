import 'dart:io';

import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

/// On-device OCR using ML Kit text recognition (Latin script).
///
/// Text never leaves the device. Results are stored alongside the page so the
/// user can search or copy them later.
class OcrService {
  TextRecognizer? _recognizer;

  TextRecognizer get _engine =>
      _recognizer ??= TextRecognizer(script: TextRecognitionScript.latin);

  Future<String> recognizeFile(String path) async {
    final input = InputImage.fromFilePath(path);
    final result = await _engine.processImage(input);
    return result.text.trim();
  }

  Future<void> dispose() async {
    await _recognizer?.close();
    _recognizer = null;
  }
}
