import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/scan_document.dart';
import '../services/document_store.dart';
import '../theme/app_theme.dart';
import 'document_screen.dart';
import 'scan_flow.dart';

/// Home screen: the user's document library.
class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  final _store = DocumentStore.instance;
  bool _busy = false;

  Future<void> _startScan() async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      final doc = await runScanFlow(context);
      if (doc != null && mounted) {
        await Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => DocumentScreen(document: doc)),
        );
        setState(() {});
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openDocument(ScanDocument doc) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => DocumentScreen(document: doc)),
    );
    if (mounted) setState(() {});
  }

  Future<void> _confirmDelete(ScanDocument doc) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete document?'),
        content: Text(
          '"${doc.title}" and its ${doc.pageCount} page(s) will be removed '
          'from this device.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Keep'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await _store.deleteDocument(doc);
      if (mounted) setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final docs = _store.documents;
    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: _Header(count: docs.length)),
            if (docs.isEmpty)
              const SliverFillRemaining(
                hasScrollBody: false,
                child: _EmptyState(),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 120),
                sliver: SliverList.separated(
                  itemCount: docs.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final doc = docs[index];
                    return _DocumentTile(
                      document: doc,
                      onTap: () => _openDocument(doc),
                      onDelete: () => _confirmDelete(doc),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _startScan,
        icon: _busy
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  color: Colors.white,
                ),
              )
            : const Icon(Icons.document_scanner_outlined),
        label: Text(_busy ? 'Opening…' : 'New scan'),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.count});

  final int count;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppColors.teal,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.crop_free_rounded,
                  color: Colors.white,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Text('ScanLite', style: theme.textTheme.titleLarge),
            ],
          ),
          const SizedBox(height: 22),
          Text('Your documents', style: theme.textTheme.displaySmall),
          const SizedBox(height: 6),
          Text(
            count == 0
                ? 'Everything you scan stays on this device.'
                : '$count document${count == 1 ? '' : 's'} · stored locally',
            style: theme.textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(32, 24, 32, 120),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 96,
            height: 96,
            decoration: BoxDecoration(
              color: AppColors.tealTint,
              borderRadius: BorderRadius.circular(28),
            ),
            child: const Icon(
              Icons.description_outlined,
              size: 44,
              color: AppColors.teal,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'No scans yet',
            style: theme.textTheme.headlineSmall,
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(
            'Tap "New scan" to capture a page. ScanLite finds the edges, '
            'straightens the page and saves it as a clean PDF.',
            style: theme.textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _DocumentTile extends StatelessWidget {
  const _DocumentTile({
    required this.document,
    required this.onTap,
    required this.onDelete,
  });

  final ScanDocument document;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final first = document.pages.isEmpty ? null : document.pages.first;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              _Thumb(page: first),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      document.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleMedium,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${document.pageCount} page'
                      '${document.pageCount == 1 ? '' : 's'} · '
                      '${DateFormat.yMMMd().format(document.modifiedAt)}',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: AppColors.inkSoft,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Delete',
                onPressed: onDelete,
                icon: const Icon(Icons.delete_outline, color: AppColors.inkSoft),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Thumb extends StatelessWidget {
  const _Thumb({required this.page});

  final ScanPage? page;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: page == null
          ? Future.value('')
          : DocumentStore.instance.pagePath(page!.fileName),
      builder: (context, snapshot) {
        final path = snapshot.data ?? '';
        return Container(
          width: 56,
          height: 72,
          decoration: BoxDecoration(
            color: AppColors.tealTint,
            borderRadius: BorderRadius.circular(10),
          ),
          clipBehavior: Clip.antiAlias,
          child: path.isEmpty
              ? const Icon(Icons.image_outlined, color: AppColors.teal)
              : Image.file(
                  File(path),
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) =>
                      const Icon(Icons.image_outlined, color: AppColors.teal),
                ),
        );
      },
    );
  }
}
