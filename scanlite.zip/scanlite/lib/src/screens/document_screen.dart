import 'dart:io';

import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../models/scan_document.dart';
import '../services/document_store.dart';
import '../services/ocr_service.dart';
import '../services/pdf_export_service.dart';
import '../theme/app_theme.dart';
import 'page_viewer_screen.dart';
import 'scan_flow.dart';

/// Document detail: page grid, rename, OCR, export and share.
class DocumentScreen extends StatefulWidget {
  const DocumentScreen({super.key, required this.document});

  final ScanDocument document;

  @override
  State<DocumentScreen> createState() => _DocumentScreenState();
}

class _DocumentScreenState extends State<DocumentScreen> {
  final _store = DocumentStore.instance;
  final _pdf = PdfExportService();
  final _ocr = OcrService();
  bool _working = false;

  ScanDocument get doc => widget.document;

  Future<void> _rename() async {
    final controller = TextEditingController(text: doc.title);
    final name = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rename document'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Title',
            border: OutlineInputBorder(),
          ),
          onSubmitted: (v) => Navigator.pop(context, v.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('Save'),
          ),
        ],
      ),
    );
    if (name != null && name.isNotEmpty) {
      setState(() => doc.title = name);
      await _store.updateDocument(doc);
    }
  }

  Future<void> _sharePdf() async {
    if (doc.pages.isEmpty) return;
    setState(() => _working = true);
    try {
      final file = await _pdf.buildPdf(doc);
      if (!mounted) return;
      await SharePlus.instance.share(
        ShareParams(files: [XFile(file.path)], text: doc.title),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not create PDF: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _runOcr() async {
    if (doc.pages.isEmpty) return;
    setState(() => _working = true);
    try {
      final buffer = StringBuffer();
      for (final page in doc.pages) {
        final path = await _store.pagePath(page.fileName);
        final text = await _ocr.recognizeFile(path);
        page.ocrText = text;
        if (text.isNotEmpty) {
          buffer.writeln(text);
          buffer.writeln();
        }
      }
      await _store.updateDocument(doc);
      if (!mounted) return;
      setState(() {});
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        builder: (context) => _OcrSheet(text: buffer.toString().trim()),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Text recognition failed: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _addPages() async {
    final added = await capturePages(context, prefixId: doc.id);
    if (added.isEmpty) return;
    doc.pages.addAll(added);
    await _store.updateDocument(doc);
    if (mounted) setState(() {});
  }

  Future<void> _openPage(int index) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PageViewerScreen(document: doc, initialIndex: index),
      ),
    );
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _ocr.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(doc.title, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            tooltip: 'Rename',
            onPressed: _rename,
            icon: const Icon(Icons.edit_outlined),
          ),
          PopupMenuButton<String>(
            onSelected: (value) {
              switch (value) {
                case 'ocr':
                  _runOcr();
                case 'pdf':
                  _sharePdf();
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem(
                value: 'ocr',
                child: ListTile(
                  leading: Icon(Icons.text_fields),
                  title: Text('Extract text (OCR)'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: 'pdf',
                child: ListTile(
                  leading: Icon(Icons.picture_as_pdf_outlined),
                  title: Text('Export PDF'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ],
          ),
        ],
      ),
      body: Stack(
        children: [
          ListView(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 120),
            children: [
              Text(
                '${doc.pageCount} page${doc.pageCount == 1 ? '' : 's'} · '
                'saved on this device',
                style: theme.textTheme.bodyMedium,
              ),
              const SizedBox(height: 18),
              const SectionLabel('Pages'),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: doc.pages.length,
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 0.72,
                ),
                itemBuilder: (context, index) {
                  return _PageCard(
                    page: doc.pages[index],
                    index: index,
                    onTap: () => _openPage(index),
                  );
                },
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _working ? null : _addPages,
                icon: const Icon(Icons.add_a_photo_outlined),
                label: const Text('Add pages'),
              ),
              const SizedBox(height: 24),
              const SectionLabel('Export'),
              Card(
                child: Column(
                  children: [
                    ListTile(
                      leading: const Icon(
                        Icons.picture_as_pdf_outlined,
                        color: AppColors.teal,
                      ),
                      title: const Text('Share as PDF'),
                      subtitle: const Text('A4 pages, one per scan'),
                      onTap: _working ? null : _sharePdf,
                    ),
                    const Divider(),
                    ListTile(
                      leading: const Icon(
                        Icons.text_fields,
                        color: AppColors.teal,
                      ),
                      title: const Text('Extract text'),
                      subtitle: const Text('On-device OCR, no upload'),
                      onTap: _working ? null : _runOcr,
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (_working)
            Positioned.fill(
              child: ColoredBox(
                color: Colors.black26,
                child: Center(
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                          SizedBox(width: 16),
                          Text('Working…'),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _working ? null : _sharePdf,
        icon: const Icon(Icons.ios_share),
        label: const Text('Share PDF'),
      ),
    );
  }
}

class _PageCard extends StatelessWidget {
  const _PageCard({
    required this.page,
    required this.index,
    required this.onTap,
  });

  final ScanPage page;
  final int index;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: DocumentStore.instance.pagePath(page.fileName),
      builder: (context, snapshot) {
        final path = snapshot.data ?? '';
        return Card(
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: onTap,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (path.isEmpty)
                  const ColoredBox(color: AppColors.tealTint)
                else
                  Image.file(
                    File(path),
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const ColoredBox(color: AppColors.tealTint),
                  ),
                Positioned(
                  left: 8,
                  bottom: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.ink.withValues(alpha: 0.72),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${index + 1}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                if (page.ocrText != null && page.ocrText!.isNotEmpty)
                  const Positioned(
                    right: 8,
                    top: 8,
                    child: Icon(
                      Icons.text_snippet_outlined,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _OcrSheet extends StatelessWidget {
  const _OcrSheet({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.7,
      maxChildSize: 0.95,
      builder: (context, controller) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.line,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Recognised text',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 12),
            Expanded(
              child: SingleChildScrollView(
                controller: controller,
                child: SelectableText(
                  text.isEmpty ? 'No text found on these pages.' : text,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppColors.ink,
                      ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
