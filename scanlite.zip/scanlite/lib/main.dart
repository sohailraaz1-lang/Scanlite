import 'package:flutter/material.dart';

import 'src/screens/library_screen.dart';
import 'src/services/document_store.dart';
import 'src/theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ScanLiteApp());
}

class ScanLiteApp extends StatelessWidget {
  const ScanLiteApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ScanLite',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      home: const _Boot(),
    );
  }
}

/// Loads the local index before showing the library so the first frame is
/// already populated (no flash of an empty list).
class _Boot extends StatefulWidget {
  const _Boot();

  @override
  State<_Boot> createState() => _BootState();
}

class _BootState extends State<_Boot> {
  late final Future<void> _ready = DocumentStore.instance.load();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _ready,
      builder: (context, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        return const LibraryScreen();
      },
    );
  }
}
